# Goldie: App Store screenshot generator for coding agents (and humans)

goldie makes App Store and Google Play screenshots, and App Store preview
videos, for a mobile app.
[argent](https://github.com/software-mansion/argent) replays flows on an iOS
simulator or an Android emulator. goldie frames the captures with a device
bezel, a background and a headline. It joins the clips into a preview video.
It checks the result against the upload rules of the stores.

goldie is framework agnostic. It drives the app through the simulator or the
emulator. It works the same for SwiftUI, UIKit, Jetpack Compose, Flutter,
React Native and Kotlin Multiplatform apps.

## Install

You need Node 20 or newer and ffmpeg on the PATH. App Store screenshots need
macOS with iOS simulators (Xcode). Google Play screenshots need an Android
emulator, which works on macOS, Linux and Windows. On Linux, argent needs
[a few extra packages](https://github.com/software-mansion/argent#linux-host-extra-prerequisites-for-android-emulators)
for Android emulators. On a Linux or Windows machine keep only `pixel-10-pro`
in `devices`; `goldie doctor` says so when an iOS device is configured on a
host that cannot run it.

Install the CLI:

```
npm i -g goldie
```

Add the skill to your coding agent:

```
npx skills add kacperkapusciak/goldie            # Cursor, Codex, any agent

/plugin marketplace add kacperkapusciak/goldie   # Claude Code
/plugin install goldie@goldie
```

The skill works with all agents that support the skills format.

## Use with a coding agent

Ask from your app repo:

```
create app store screenshots using goldie
```

The agent asks which stores to target. It explores the app, writes the flows
and the config, and opens the studio. Follow-ups such as `use a dark
background` edit the same files.

## Use by hand

Copy `goldie.config.example.ts` to `goldie.config.ts`. Point its scenes at
argent flows in `.argent/flows`. Then run:

```
goldie doctor     Check tools, simulators and flows
goldie all        Capture, frame, render the preview and verify
goldie studio     Preview and tweak the assets in the browser
```

The output goes to `out/screenshots/<device>/<locale>/` and
`out/previews/<device>/<locale>/`. The iPhone gets 1320 x 2868 screenshots
and an 886 x 1920 H.264 preview. Google Play gets 1080 x 1920 phone and
1440 x 2560 tablet screenshots.
A preview must run 15 to 30 seconds.

## Google Play

The `pixel-10-pro` device key renders Google Play phone screenshots
(1080 x 1920) from the same scenes. The example config already lists this
key. Remove it from `devices` for an iOS-only run. Argent flows also replay
on Android, so the scene flows are shared. A flow works on both platforms
when its selectors match. The captures come from an Android emulator. Its
AVD must use the Pixel 10 Pro or the Pixel 9 Pro hardware profile (both have
a 1280 x 2856 screen). goldie reuses a running emulator that matches, or
boots the AVD itself. Create the AVD from either device definition
(Android Studio > Device Manager). Then add the build to the config:

```ts
devices: ["iphone-6.9", "pixel-10-pro"],
android: {
  appPath: "/path/to/app-release.apk",
  applicationId: "com.example.app",
},
```

goldie frames Android tiles with the bundled Pixel 10 Pro bezel. The `frame`
variant is iPhone art, so it does not apply to them. `android.frame` swaps
in your own art and its geometry. The Play Store promo video is a YouTube
link, so `preview` and `all` record the preview scene on the emulator and
render a portrait video for you to post on YouTube yourself. Apple's 15-30
second window does not apply to it.

### Android tablets

The `pixel-tablet` device key renders Google Play tablet screenshots
(1440 x 2560, portrait) from the same scenes, framed with the bundled Pixel
Tablet bezel. Create an AVD from the Pixel Tablet device definition; goldie
pins it to portrait before capturing. `android.tabletFrame` swaps in your own
art.

```ts
devices: ["iphone-6.9", "pixel-10-pro", "pixel-tablet"],
```

## Localization

Every copy record (`headline`, `subhead`, badge `text`, `store.subtitle`,
`store.description`) takes one entry per locale in `locales`; `goldie doctor`
lists missing ones. By default the app is captured once, in the first
locale, and every locale reuses those captures under its own headlines. To
show the app's own translated UI, capture each locale:

```ts
locales: ["en-US", "bn-BD"],
localizedCapture: true,
```

goldie then switches the simulator's language (iOS) or the app's per-app
locale (Android 13+) before each locale's capture, and writes to
`out/raw/<device>/<locale>/`. A flow that taps by visible text will not find
it in another language; give that scene a `localeFlows: { "bn-BD": "home-bn" }`
entry. `goldie capture --locale bn-BD` re-captures one locale. Right-to-left
copy (Arabic, Hebrew, Persian, Urdu) is laid out right to left.

## Design

https://github.com/user-attachments/assets/d6171a90-8fc1-437b-a574-5a8547068a3c

The studio switches devices, backgrounds, templates, bezel, fonts and
per-tile copy. It saves the choices to `goldie.design.json`, so the CLI
renders the same result. The config also takes:

- `frame`: `17-pro-blue`, `17-pro-silver`, `17-pro-orange`, or a custom
  bezel image; `theme.screenOnly: true` removes it.
- `theme.template`: `editorial`, `showcase`, `magazine`, `storyboard`,
  `dynamic`, or your own layout sequence from `classic`, `copy-below`, `hero`,
  `offset`, `tilt`, `tilt-right`, `duo`, `duo-tilt`, `panorama`,
  `panorama-duo`, `minimal`.
- `theme.fontFamily`: a CSS font stack. Merriweather, DM Mono, Lato, DM Sans,
  Montserrat and Noto Sans SC (Simplified Chinese) are bundled.
- `fonts`: your own typefaces, TTF or OTF files next to the config, one per
  weight (headlines use 700, subheads 400). The studio's "Upload a font" does
  the same and stores the files in `goldie-fonts/`.

  ```ts
  fonts: [{ family: "Inter", files: { 400: "fonts/Inter-Regular.ttf", 700: "fonts/Inter-Bold.ttf" } }],
  theme: { fontFamily: '"Inter", sans-serif', /* ... */ },
  ```

- `theme.localeFonts`: a font stack per locale, for scripts the main font
  cannot draw. The exporter never falls back to system fonts, so Bengali,
  Arabic, Thai or Devanagari copy needs a custom font that has the glyphs:
  `localeFonts: { "bn-BD": '"Noto Sans Bengali", sans-serif' }`.
- `decorations`: badges or images layered behind the device.

## Remarks

- Use a Release build. Debug builds paint LogBox banners into the captures.
- Flows fail when the app changes. Ask the coding agent to repair them, or
  re-record them with argent.

## Sponsored by Software Mansion

goldie is sponsored by [Software Mansion](https://swmansion.com), the
software agency that created [Argent](https://github.com/software-mansion/argent).
You can [hire Software Mansion](https://swmansion.com/contact) for your next project.

<a href="https://swmansion.com"><img src="assets/software-mansion-logo-positive-s-left-top@1x.png" alt="Software Mansion" width="200" /></a>
